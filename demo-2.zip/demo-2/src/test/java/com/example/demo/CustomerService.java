package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	@Autowired
	public CustomerRepository customerRepo;
	public String customer()
	{
		return "Welcome to Restful Service";
	}
	public String serviceTest()
	{
		return "Hello Hi";
	}
	public void generateCustomer(Customer cust) { // to insert a row or create datas in db using post method in postman and update option in appliaction.properties
		/*System.out.println(cust.getCustomerId());
		System.out.println(cust.getCustomerName());
		System.out.println(cust.getCustomerphone());
		System.out.println(cust.getCustomerEmail());*/
		customerRepo.save(cust);
	}
	public List<Customer> getAllCustomers() { // to list datas from db using get method in postman
		// TODO Auto-generated method stub
		return customerRepo.findAll();
	}
	public Customer getCustomerById(Long cId) { // to list single data from db using get method in postman
		// TODO Auto-generated method stub 
		Optional<Customer> ocust = customerRepo.findById(cId);
		return ocust.get();
	}
	public void deleteCustomerById(Long cId) { // to delete single data from db using delete method in postman
		// TODO Auto-generated method stub
		customerRepo.deleteById(cId);
	}
	public void updateCustomerById(Customer cu,Long cId) {// to update  data in db using put method in postman
		// TODO Auto-generated method stub
		Optional<Customer> ucust = customerRepo.findById(cId);
		if(ucust.isPresent())
		{
			cu.setCustomerId(cId);
			customerRepo.save(cu);
		}
		else
		{
			System.out.println("Not found");
		}
	}
	
}
